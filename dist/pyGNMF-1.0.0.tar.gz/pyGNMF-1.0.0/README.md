# pyGNMF
 Python Library for Generalised Non-Negative Matrix Factorisiation (GNMF)


This Python library implements GNMF method introduced in article titled "Generalised Non-Negative Matrix Factorisation for Air Pollution Source Apportionment" published in the Science of Total Environment Journal.

Following are the details of the code.
